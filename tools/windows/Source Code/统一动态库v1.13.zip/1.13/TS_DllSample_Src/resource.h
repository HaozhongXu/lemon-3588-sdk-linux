//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DllToolSample.rc
//
#define IDD_DLLTOOLSAMPLE_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDC_EDT_SN                      1000
#define IDC_EDT_MAC                     1001
#define IDC_EDT_BT                      1002
#define IDC_EDT_IMEI                    1003
#define IDC_BUTTON1                     1004
#define IDC_BTN_SN_WRITE                1004
#define IDC_BTN_MAC_WRITE               1005
#define IDC_BTN_BT_WRITE                1006
#define IDC_BTN_IMEI_WRITE              1007
#define IDC_BTN_ALL_WRITE               1008
#define IDC_CHK_SN                      1009
#define IDC_CHK_MAC                     1010
#define IDC_CHK_BT                      1011
#define IDC_CHK_IMEI                    1012
#define IDC_EDT_CUSTOM_FILE             1013
#define IDC_BTN_CUSTOM_BROWSE           1014
#define IDC_EDT_CUSTOM_OFFSET           1015
#define IDC_BTN_CUSTOM_WRITE            1016
#define IDC_STATIC_SN                   1017
#define IDC_STATIC_MAC                  1018
#define IDC_STATIC_BT                   1019
#define IDC_STATIC_IMEI                 1020
#define IDC_STATIC_ALL                  1021
#define IDC_STATIC_CUSTOM               1022
#define IDC_STATIC_OFFSET               1023
#define IDC_STATIC_DEVICE               1024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
